
<?php
echo "HOME";

?>
    